﻿using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;

namespace laba28_29
{
    internal class Datab : DbContext
    {
        string connect = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=Policlinik2;Integrated Security=True;Encrypt=True";

        public DbSet<Pacients> Pacient { get; set; }
        public DbSet<Uslugas> Usluga { get; set; }
        public DbSet<Obrashenies> Obrashenie { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(connect);
        }
    }
}
