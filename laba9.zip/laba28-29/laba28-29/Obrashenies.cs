﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace laba28_29
{
    [Table("Obrashenie")]
    public class Obrashenies
    {
        [Key]
        public int Id { get; set; }
        [Column("Id_Pacient")]
        public int Id_Pacient { get; set; }
        [Column("Kod_Uslug")]
        public int Kod_Uslug { get; set; }
        [Column("Date")]
        public String Date { get; set; }
        [Column("Stoimost")]
        public String Stoimost { get; set; }
        public Obrashenies() { }
        public Obrashenies(int id_Pacient, int kod_Uslug,  string stoimost, string date)
        {
            Id_Pacient = id_Pacient;
            Kod_Uslug = kod_Uslug;
            Stoimost = stoimost;
            Date = date;
        }
    }
}
