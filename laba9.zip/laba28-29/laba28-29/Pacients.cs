﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace laba28_29
{
    [Table("Pacient")]
    public class Pacients
    {
        [Key]
        public int Id { get; set; }
        [Column("Familia")]
        public String Familia { get; set; }
        [Column("Name")]
        public String Name { get; set; }
        [Column("Secondname")]
        public String Secondname { get; set; }
        [Column("Birthday")]
        public String Birthday { get; set; }
        [Column("Adress")]
        public String Adress { get; set; }
        public Pacients() { }
        public Pacients(string familia, string name, string secondname, string birthday, string adress)
        {
            Familia = familia;
            Name = name;
            Secondname = secondname;
            Birthday = birthday;
            Adress = adress;
        }
    }
}
