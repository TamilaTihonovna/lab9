using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;
using System.Linq;

namespace laba28_29.Pages
{
    public class AddPacientModel : PageModel
    {
        public List<Pacients> Pacient { get; set; }

        [BindProperty]
        public int? PacientId { get; set; }
        [BindProperty]
        public string Familia { get; set; }
        [BindProperty]
        public string Name { get; set; }
        [BindProperty]
        public string Secondname { get; set; }
        [BindProperty]
        public string Birthday { get; set; }
        [BindProperty]
        public string Adress { get; set; }

        // ����� ��� �������� ������ ��������� � ������ ��� ��������������
        public void OnGet(int? id = null)
        {
            using (var context = new Datab())
            {
                Pacient = context.Pacient.ToList();
                if (id.HasValue)
                {
                    var pac = context.Pacient.Find(id.Value);
                    if (pac != null)
                    {
                        PacientId = pac.Id;
                        Familia = pac.Familia;
                        Name = pac.Name;
                        Secondname = pac.Secondname;
                        Birthday = pac.Birthday;
                        Adress = pac.Adress;
                    }
                }
            }
        }

        // ����� ��� ���������� ������ ��������
        public IActionResult OnPostAdd()
        {
            if (ModelState.IsValid)
            {
                using (var context = new Datab())
                {
                    Pacients pac = new Pacients(Familia, Name, Secondname, Birthday, Adress);
                    context.Pacient.Add(pac);
                    context.SaveChanges();
                }
                return RedirectToPage("./Index");
            }
            return Page();
        }

        // ����� ��� ���������� ������ ��������
        public IActionResult OnPostEdit()
        {
            if (PacientId.HasValue && ModelState.IsValid)
            {
                using (var context = new Datab())
                {
                    var pac = context.Pacient.Find(PacientId.Value);
                    if (pac != null)
                    {
                        pac.Familia = Familia;
                        pac.Name = Name;
                        pac.Secondname = Secondname;
                        pac.Birthday = Birthday;
                        pac.Adress = Adress;
                        context.SaveChanges();
                    }
                }
                return RedirectToPage("./Index");
            }
            return Page();
        }

        // ����� ��� �������� ��������
        public IActionResult OnPostDelete(int id)
        {
            using (var context = new Datab())
            {
                var pac = context.Pacient.Find(id);
                if (pac != null)
                {
                    context.Pacient.Remove(pac);
                    context.SaveChanges();
                }
            }
            return RedirectToPage("./Index");
        }
    }
}

