using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using System.Collections.Generic;
using System.Linq;

namespace laba28_29.Pages
{
    public class AddUslugaModel : PageModel
    {
        public List<Uslugas> Uslugas { get; set; }

        [BindProperty]
        public int? UslugaId { get; set; }
        [BindProperty]
        public string Name { get; set; }
        [BindProperty]
        public string Stoimost { get; set; }
        [BindProperty]
        public string Type { get; set; }

        // ����� ��� �������� ������ ����� � ������ ��� ��������������
        public void OnGet(int? id = null)
        {
            using (var context = new Datab())
            {
                Uslugas = context.Usluga.ToList();
                if (id.HasValue)
                {
                    var usl = context.Usluga.Find(id.Value);
                    if (usl != null)
                    {
                        UslugaId = usl.Kod;
                        Name = usl.Name;
                        Type = usl.Type;
                        Stoimost = usl.Stoimost;
                    }
                }
            }
        }

        // ����� ��� ���������� ����� ������
        public IActionResult OnPostAdd()
        {
            if (ModelState.IsValid)
            {
                using (var context = new Datab())
                {
                    Uslugas usl = new Uslugas(Name, Stoimost, Type);
                    context.Usluga.Add(usl);
                    context.SaveChanges();
                }
                return RedirectToPage("./Index");
            }
            return Page();
        }

        // ����� ��� ���������� ������ ������
        public IActionResult OnPostEdit()
        {
            if (UslugaId.HasValue && ModelState.IsValid)
            {
                using (var context = new Datab())
                {
                    var usl = context.Usluga.Find(UslugaId.Value);
                    if (usl != null)
                    {
                        usl.Name = Name;
                        usl.Type = Type;
                        usl.Stoimost = Stoimost;
                        context.SaveChanges();
                    }
                }
                return RedirectToPage("./Index");
            }
            return Page();
        }

        // ����� ��� �������� ������
        public IActionResult OnPostDelete(int id)
        {
            using (var context = new Datab())
            {
                var usl = context.Usluga.Find(id);
                if (usl != null)
                {
                    context.Usluga.Remove(usl);
                    context.SaveChanges();
                }
            }
            return RedirectToPage("./Index");
        }
    }
}
