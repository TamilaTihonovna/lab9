using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace laba28_29.Pages
{
    public class Pr
    {
        public int Id { get; set; }
        public string Pacient { get; set; }
        public string Usluga { get; set; }
        public string Date { get; set; }
        public string Stoimost { get; set; }
        int i = 0;
        public Pr() { }
        public Pr(string pacientid, string uslugaid, string date, string stoimost)
        {
            Id = ++i;
            Pacient = pacientid;
            Usluga = uslugaid;
            Date = date;
            Stoimost = stoimost;
        }
    }
    public class IndexModel : PageModel
    {
        public List<Pr> pr { get; set; }
        private readonly ILogger<IndexModel> _logger;
        public List<Pacients> pacients { get; set; }
        public List<Uslugas> uslugas { get; set; }
        public IndexModel(ILogger<IndexModel> logger)
        {
            _logger = logger;
            var context = new Datab();
            pr = new List<Pr>();
            pacients = new List<Pacients>();
            uslugas = new List<Uslugas>();

            pr = (from o in context.Obrashenie
                  join p in context.Pacient on o.Id_Pacient equals p.Id
                  join u in context.Usluga on o.Kod_Uslug equals u.Kod
                  select new Pr(p.Familia, u.Name, o.Date, o.Stoimost)).ToList();

            var pacnts = context.Pacient.ToList();

            foreach (var p in pacnts)
            {
                pacients.Add(p);
            }

            var usls = context.Usluga.ToList();
            foreach (var u in usls)
            {
                uslugas.Add(u);
            }
        }

        public void OnGet()
        {

        }      

        public IActionResult OnPost(string action, int selectedPacient, int selectedUsluga, string stoimost, DateTime date)
        {
            if (action == "addPacient")
            {
                return RedirectToPage("./AddPacient");
            }
            else if (action == "addUsluga")
            {
                return RedirectToPage("./AddUsluga");
            }
            else if (action == "addObrashenie")
            {
                using (var context = new Datab())
                {
                    var obr = new Obrashenies(selectedPacient, selectedUsluga, stoimost,date.ToString("dd.MM.yyyy"));
                    context.Obrashenie.Add(obr);
                    context.SaveChanges();
                }
                return RedirectToPage();
            }
            else
            {
                return RedirectToPage("./Index");
            }
        }
    }
}
