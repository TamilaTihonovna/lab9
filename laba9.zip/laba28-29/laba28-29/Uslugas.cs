﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace laba28_29
{
    [Table("Usluga")]
    public class Uslugas
    {
        [Key]
        public int Kod { get; set; }
        [Column("Name")]
        public string Name { get; set; }
        [Column("Stoimost")]
        public String Stoimost { get; set; }
        [Column("Type")]
        public string Type { get; set; }
        public Uslugas() { }
        public Uslugas(string name, string stoimost, string type)
        {
            Name = name;
            Stoimost = stoimost;
            Type = type;
        }
    }
}
